public enum Puanlar
{
    DusmanVuruldu = 10,
    //DusmanYokedildi=50,
    SiniraVurdu = -10,
}

public enum Hasarlar
{
    dusman1Carpti = 75,
    dusman2Carpti = 50,

    dusman3Carpti = 30,
    dusmanRoketiCarpti = 25,
}